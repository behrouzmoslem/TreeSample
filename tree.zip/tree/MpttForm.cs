﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using MPTT.BLL;
using MPTT.DAL;
using System.IO;

namespace tree
{
    public partial class mpttForm : Form
    {
        private char _delimiter = '#';
        MpttCoreEngine engine = new MpttCoreEngine();

        private string _connectionString;
        public string ConnectionString
        {
            get { return _connectionString; }
            set 
            { 
                _connectionString = value;
                SetStatusBarText();
                WriteConString(_connectionString);
            }
        }

        public mpttForm()
        {
            InitializeComponent();
            ConnectionString = ReadConString();
        }

        private string ReadConString()
        {
            string conString = " ";
            try { conString = File.ReadAllText("constring.txt"); }
            catch { }
            return conString;
        }

        private void  WriteConString(string conString)
        {
            try { File.WriteAllText("constring.txt", conString); }
            catch { }
        }

        private void btnLoadDb_Click(object sender, EventArgs e)
        {
            LoadDb();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveDb();
            //the previous step doesn't return left and right values into MpttTreeNode objects refrenced by Tag property
            //So, we have to reload the recently saved tree from database
            LoadDb();
        }


        private void btnToText_Click(object sender, EventArgs e)
        {
            TextReflection();
        }

        private void btnToTree_Click(object sender, EventArgs e)
        {
            TreeReflection();
        }

        private void textual_CheckedChanged(object sender, EventArgs e)
        {
            TextReflection();//instantly reflects tree into text view 
            delimiterLabel.Visible = textual.Checked;
            delimiter.Visible = textual.Checked;
        }

        private void delimiter_TextChanged(object sender, EventArgs e)
        {
            char t = (delimiter.Text.Length > 0 ? delimiter.Text[0] : '#');
            if (t == '*')
            {
                MessageBox.Show("Please use another delimiter");
                return;
            }
            _delimiter = t;
        }

        private void btnMakeTree_Click(object sender, EventArgs e)
        {
            FormulateDummyTree();
        }

        private void btnConnectionString_Click(object sender, EventArgs e)
        {
            string con = PromptForConnectionString(_connectionString);
            if (con == "")
                return;
            ConnectionString = con;
        }

        private void SetStatusBarText()
        {
            toolstripMsg.Text = "Connectio String: [" + _connectionString + "]";
        }

        private void LoadDb()
        {
            try
            {
                treeView.Nodes.Clear();
                TreeNode node = null;
                engine.SetConnectionString(_connectionString);
                node = engine.ConvertMpttIntoTree();
                if (node != null)
                {
                    treeView.Nodes.Add(node);
                    treeView.ExpandAll();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\r\nThe Connection string may not be correct");
            }
        }

        private void SaveDb()
        {
            if (treeView.Nodes.Count <= 0)
                return;
            try
            {
                engine.SetConnectionString(_connectionString);
                engine.ConvertTreeIntoMptt(treeView.Nodes[0]);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\r\nThe Connection string may not be correct");
            }
        }

        private void TreeReflection()
        {
            char t = (delimiter.Text.Length > 0 ? delimiter.Text[0] : '#');
            engine.LevelDelimiter = t;
            //
            treeView.Nodes.Clear();
            TreeNode node = null;
            if (textual.Checked)
                node = engine.ConvertTextIntoTree(textView.Text, _delimiter, '*');
            else//tabular
                node = engine.ConvertTextTableIntoTree(textView.Text, true);
            if (node != null)
            {
                treeView.Nodes.Add(node);
                treeView.ExpandAll();
            }
        }

        private void TextReflection()
        {
            if (treeView.Nodes.Count <= 0)
                return;
            char t = (delimiter.Text.Length > 0 ? delimiter.Text[0] : '#');
            engine.LevelDelimiter = t;
            if (textual.Checked)
            {
                textView.Text = engine.ConvertTreeIntoText(treeView.Nodes[0], false);
            }
            else
            {
                textView.Text = engine.ConvertTreeIntoTable(treeView.Nodes[0], false);
            }
        }

        private void FormulateDummyTree()
        {
            textView.Text = engine.FormatDumyTree(textual.Checked,Int32.Parse(count.Text),_delimiter,title.Text);
        }

        /// <summary>
        /// Displays a Connection String Builder (DataLinks) dialog.
        /// 
        /// Credits:
        /// http://www.codeproject.com/cs/database/DataLinks.asp
        /// http://www.codeproject.com/cs/database/DataLinks.asp?df=100&forumid=33457&select=1560237#xx1560237xx
        /// 
        /// Required COM references:
        /// %PROGRAMFILES%\Microsoft.NET\Primary Interop Assemblies\adodb.dll
        /// %PROGRAMFILES%\Common Files\System\Ole DB\OLEDB32.DLL
        /// </summary>
        /// <param name="currentConnectionString">Previous database connection string</param>
        /// <returns>Selected connection string</returns>
        public static string PromptForConnectionString(string currentConnectionString)
        {
            try
            {
                MSDASC.DataLinks dataLinks = new MSDASC.DataLinksClass();
                ADODB.Connection dialogConnection;
                string generatedConnectionString = string.Empty;

                if (currentConnectionString == String.Empty)
                {
                    dialogConnection = (ADODB.Connection)dataLinks.PromptNew();
                    generatedConnectionString = dialogConnection.ConnectionString.ToString();
                }
                else
                {
                    dialogConnection = new ADODB.Connection();
                    dialogConnection.Provider = "SQLOLEDB.1";
                    ADODB.Property persistProperty = dialogConnection.Properties["Persist Security Info"];
                    persistProperty.Value = true;

                    dialogConnection.ConnectionString = currentConnectionString;
                    dataLinks = new MSDASC.DataLinks();

                    object objConn = dialogConnection;
                    if (dataLinks.PromptEdit(ref objConn))
                    {
                        generatedConnectionString = dialogConnection.ConnectionString.ToString();
                    }
                    else
                    {
                        return "";
                    }
                }
                generatedConnectionString = generatedConnectionString.Replace("Provider=SQLOLEDB.1;", string.Empty);
                if (
                        !generatedConnectionString.Contains("Integrated Security=SSPI")
                        && !generatedConnectionString.Contains("Trusted_Connection=True")
                        && !generatedConnectionString.Contains("Password=")
                        && !generatedConnectionString.Contains("Pwd=")
                    )
                    if (dialogConnection.Properties["Password"] != null)
                        generatedConnectionString += ";Password=" + dialogConnection.Properties["Password"].Value.ToString();

                return generatedConnectionString;
            }
            catch
            {
                return "";
            }
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            if (treeView.Nodes.Count <= 0)
                return;
            Bitmap bmp = engine.DrawTree(treeView.Nodes[0]);
            TreePreview preview = new TreePreview(bmp);
            preview.Show();
        }
    }
}
