﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tree
{
    public partial class TreePreview : Form
    {
        public TreePreview(Bitmap bmp)
        {
            InitializeComponent();
            //
            pictureBox.Size = new Size(bmp.Width, bmp.Height);
            pictureBox.Location = new Point(0, 0);
            pictureBox.Image = bmp;
        }
    }
}
