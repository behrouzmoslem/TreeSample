﻿namespace tree
{
    partial class mpttForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.treeView = new System.Windows.Forms.TreeView();
            this.textView = new System.Windows.Forms.TextBox();
            this.btnToText = new System.Windows.Forms.Button();
            this.btnToTree = new System.Windows.Forms.Button();
            this.btnLoadDb = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnMakeTree = new System.Windows.Forms.Button();
            this.btnConnectionString = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDraw = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.TextBox();
            this.delimiterLabel = new System.Windows.Forms.Label();
            this.tabular = new System.Windows.Forms.RadioButton();
            this.delimiter = new System.Windows.Forms.TextBox();
            this.textual = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.count = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolstripMsg = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView
            // 
            this.treeView.BackColor = System.Drawing.Color.PapayaWhip;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(3, 21);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(321, 234);
            this.treeView.TabIndex = 0;
            // 
            // textView
            // 
            this.textView.BackColor = System.Drawing.Color.LemonChiffon;
            this.textView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textView.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textView.Location = new System.Drawing.Point(428, 21);
            this.textView.Multiline = true;
            this.textView.Name = "textView";
            this.textView.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textView.Size = new System.Drawing.Size(322, 234);
            this.textView.TabIndex = 1;
            // 
            // btnToText
            // 
            this.btnToText.BackColor = System.Drawing.Color.AliceBlue;
            this.btnToText.Location = new System.Drawing.Point(22, 3);
            this.btnToText.Name = "btnToText";
            this.btnToText.Size = new System.Drawing.Size(48, 23);
            this.btnToText.TabIndex = 2;
            this.btnToText.Text = ">>";
            this.btnToText.UseVisualStyleBackColor = false;
            this.btnToText.Click += new System.EventHandler(this.btnToText_Click);
            // 
            // btnToTree
            // 
            this.btnToTree.BackColor = System.Drawing.Color.AliceBlue;
            this.btnToTree.Location = new System.Drawing.Point(22, 32);
            this.btnToTree.Name = "btnToTree";
            this.btnToTree.Size = new System.Drawing.Size(48, 23);
            this.btnToTree.TabIndex = 3;
            this.btnToTree.Text = "<<";
            this.btnToTree.UseVisualStyleBackColor = false;
            this.btnToTree.Click += new System.EventHandler(this.btnToTree_Click);
            // 
            // btnLoadDb
            // 
            this.btnLoadDb.BackColor = System.Drawing.Color.AliceBlue;
            this.btnLoadDb.Location = new System.Drawing.Point(4, 17);
            this.btnLoadDb.Name = "btnLoadDb";
            this.btnLoadDb.Size = new System.Drawing.Size(62, 23);
            this.btnLoadDb.TabIndex = 6;
            this.btnLoadDb.Text = "Load DB";
            this.btnLoadDb.UseVisualStyleBackColor = false;
            this.btnLoadDb.Click += new System.EventHandler(this.btnLoadDb_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.AliceBlue;
            this.btnSave.Location = new System.Drawing.Point(72, 17);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(57, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save DB";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnMakeTree
            // 
            this.btnMakeTree.BackColor = System.Drawing.Color.AliceBlue;
            this.btnMakeTree.Location = new System.Drawing.Point(10, 30);
            this.btnMakeTree.Name = "btnMakeTree";
            this.btnMakeTree.Size = new System.Drawing.Size(147, 25);
            this.btnMakeTree.TabIndex = 8;
            this.btnMakeTree.Text = "New Dumy Tree";
            this.btnMakeTree.UseVisualStyleBackColor = false;
            this.btnMakeTree.Click += new System.EventHandler(this.btnMakeTree_Click);
            // 
            // btnConnectionString
            // 
            this.btnConnectionString.BackColor = System.Drawing.Color.AliceBlue;
            this.btnConnectionString.Location = new System.Drawing.Point(210, 18);
            this.btnConnectionString.Name = "btnConnectionString";
            this.btnConnectionString.Size = new System.Drawing.Size(108, 23);
            this.btnConnectionString.TabIndex = 10;
            this.btnConnectionString.Text = "Connection String";
            this.btnConnectionString.UseVisualStyleBackColor = false;
            this.btnConnectionString.Click += new System.EventHandler(this.btnConnectionString_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(428, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Textual/Tabular View";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Tree View:";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textView, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.treeView, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 81F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(753, 339);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnDraw);
            this.panel3.Controls.Add(this.btnSave);
            this.panel3.Controls.Add(this.btnLoadDb);
            this.panel3.Controls.Add(this.btnConnectionString);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 261);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(321, 75);
            this.panel3.TabIndex = 18;
            // 
            // btnDraw
            // 
            this.btnDraw.BackColor = System.Drawing.Color.AliceBlue;
            this.btnDraw.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDraw.Location = new System.Drawing.Point(147, 18);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(40, 23);
            this.btnDraw.TabIndex = 11;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = false;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnToTree);
            this.panel1.Controls.Add(this.btnToText);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(330, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(92, 234);
            this.panel1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.title);
            this.panel2.Controls.Add(this.delimiterLabel);
            this.panel2.Controls.Add(this.tabular);
            this.panel2.Controls.Add(this.delimiter);
            this.panel2.Controls.Add(this.textual);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.count);
            this.panel2.Controls.Add(this.btnMakeTree);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(428, 261);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(322, 75);
            this.panel2.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Title:";
            // 
            // title
            // 
            this.title.Location = new System.Drawing.Point(41, 5);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(116, 20);
            this.title.TabIndex = 23;
            this.title.Text = "Node";
            // 
            // delimiterLabel
            // 
            this.delimiterLabel.AutoSize = true;
            this.delimiterLabel.Location = new System.Drawing.Point(163, 10);
            this.delimiterLabel.Name = "delimiterLabel";
            this.delimiterLabel.Size = new System.Drawing.Size(62, 13);
            this.delimiterLabel.TabIndex = 20;
            this.delimiterLabel.Text = "Level mark:";
            // 
            // tabular
            // 
            this.tabular.AutoSize = true;
            this.tabular.Checked = true;
            this.tabular.Location = new System.Drawing.Point(254, 34);
            this.tabular.Name = "tabular";
            this.tabular.Size = new System.Drawing.Size(61, 17);
            this.tabular.TabIndex = 11;
            this.tabular.TabStop = true;
            this.tabular.Text = "Tabular";
            this.tabular.UseVisualStyleBackColor = true;
            // 
            // delimiter
            // 
            this.delimiter.Location = new System.Drawing.Point(231, 7);
            this.delimiter.Name = "delimiter";
            this.delimiter.Size = new System.Drawing.Size(17, 20);
            this.delimiter.TabIndex = 4;
            this.delimiter.Text = "#";
            this.delimiter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.delimiter.TextChanged += new System.EventHandler(this.delimiter_TextChanged);
            // 
            // textual
            // 
            this.textual.AutoSize = true;
            this.textual.Checked = true;
            this.textual.Location = new System.Drawing.Point(254, 6);
            this.textual.Name = "textual";
            this.textual.Size = new System.Drawing.Size(61, 17);
            this.textual.TabIndex = 10;
            this.textual.TabStop = true;
            this.textual.Text = "Textual";
            this.textual.UseVisualStyleBackColor = true;
            this.textual.CheckedChanged += new System.EventHandler(this.textual_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(163, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Count:";
            // 
            // count
            // 
            this.count.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.count.Location = new System.Drawing.Point(209, 36);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(39, 13);
            this.count.TabIndex = 21;
            this.count.Text = "10";
            this.count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(330, 261);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(92, 75);
            this.panel4.TabIndex = 19;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolstripMsg});
            this.statusStrip.Location = new System.Drawing.Point(0, 317);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(753, 22);
            this.statusStrip.TabIndex = 16;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolstripMsg
            // 
            this.toolstripMsg.Name = "toolstripMsg";
            this.toolstripMsg.Size = new System.Drawing.Size(415, 17);
            this.toolstripMsg.Text = "Add SQL2005 Server Connection using the button named [Connection String]";
            // 
            // mpttForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(753, 339);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "mpttForm";
            this.Text = "Modified Preorder Tree Traversal";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.TextBox textView;
        private System.Windows.Forms.Button btnToText;
        private System.Windows.Forms.Button btnToTree;
        private System.Windows.Forms.Button btnLoadDb;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnMakeTree;
        private System.Windows.Forms.Button btnConnectionString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton tabular;
        private System.Windows.Forms.RadioButton textual;
        private System.Windows.Forms.Label delimiterLabel;
        private System.Windows.Forms.TextBox delimiter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox count;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolstripMsg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.Button btnDraw;
    }
}

