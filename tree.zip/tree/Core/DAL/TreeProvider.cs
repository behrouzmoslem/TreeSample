﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;
using MPTT.DAL;
using MPTT.BLL;
using System.Data.SqlClient;

/// <summary>
/// Tree functionalities Add, Insert, Delete and Modify
/// Hirarchical tree representation into SQL table
/// Modified Preorder Tree Traversal (MPTT) schema to represent Hajj data into DB
/// </summary>
namespace MPTT.DAL
{
    public abstract class TreeProvider : DataAccess
    {
        public string[] Fields = {"ID","parentID","lft","rgt","leafID","isLeaf","Title"};

        public TreeProvider()
            : base()
        {
        }
        public TreeProvider(string conString) :
            base(conString)
        {
        }
        public abstract int AddNode(string title, int parentID,bool rebuiled);
        public abstract void DeleteNode(int id);
        public abstract List<MpttNode> GetLevelZeroNodes();
        public abstract List<MpttNode> GetChildren(int parentID);
        public abstract List<MpttNode> GetSubTree(int parentID, bool includeParent);
        public abstract MpttNode GetNodeByLeafID(int leafID);

        public abstract List<MpttNode> GetSiblings(int nodeID);
        public abstract int GetParentID(int nodeID);
        public abstract MpttNode GetNode(int nodeID);
        
        public abstract void TruncateTable();
        public abstract int RebuildTree(int parentID, int lft);
        public abstract void IdentifyAllLeafIDs(int startLeafID);
        public abstract void IdentifyAllNodes(int startID);
        public abstract void IdentifySingleLeafID(int ID, int leafID); 
        public abstract int DescendantsCount(int parentID);
        
        

        /// <summary>
        /// Returns a new MpttTreeNode instance filled with the DataReader's current record data
        /// </summary>
        protected virtual MpttNode GetNodeFromReader(IDataReader reader)
        {
            return new MpttNode(
               (int)reader[Fields[0]],
               (int)reader[Fields[1]],
               (int)reader[Fields[2]],
               (int)reader[Fields[3]],
               (int)reader[Fields[4]],
               ((bool)reader[Fields[5]]) ? 1 : 0,
               reader[Fields[6]].ToString());
        }

        /// <summary>
        /// Returns a collection of MpttTreeNode objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<MpttNode> GetNodeCollectionFromReader(IDataReader reader)
        {
            List<MpttNode> nodes = new List<MpttNode>();
            while (reader.Read())
                nodes.Add(GetNodeFromReader(reader));
            reader.Close();
            return nodes;
        }
    }
}