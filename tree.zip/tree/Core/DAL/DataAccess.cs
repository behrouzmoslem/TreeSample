﻿using System;
using System.Data;
using System.Configuration;
using System.Data.Common;
using System.Collections.Generic;
using System.Data.SqlClient;
using MPTT.BLL;

namespace MPTT.DAL
{
    public abstract class DataAccess
    {
        public static Boolean useStaticSingleConection = false;
        private static SqlConnection conStatic = null;
        protected SqlConnection con;
        protected Boolean endUpdate;

        private string _connectionString = "";
        public string ConnectionString
        {
            get { return _connectionString; }
            set { _connectionString = value; }
        }

        public DataAccess()
        {
            this.ConnectionString = "";
            Init();
        }

        public DataAccess(string conString)
        {
            this.ConnectionString = conString;
            Init();
        }

        protected virtual void Init()
        {
            endUpdate = false;
        }

        public virtual void BegingUpdate()
        {
            try
            {
                if (conStatic == null || conStatic.State!=ConnectionState.Open)
                {
                    con = new SqlConnection(ConnectionString);
                    con.Open();
                    conStatic = con;
                }
                con = conStatic;
            }
            catch
            {
                con = null;
            }
        }

        public virtual void EndUpdate()
        {
            if (con != null)
            {
                if(useStaticSingleConection)
                    con = null;
                else
                {
                    //remove unmanaged resources of our static connection by
                    //calling dispose method after closing the connection
                    con.Close();
                    con.Dispose();
                    conStatic = null;
                    con = null;
                }
            }
        }

        protected virtual Boolean InternalBeginUpdate()
        {
            //Support multiple call to this function
            //by checking con at first
            if (con != null)
                return true;
            //
            BegingUpdate();
            endUpdate = (con != null);
            return (con != null);
        }

        protected virtual void InternalEndUpdate()
        {
            if (endUpdate)
                EndUpdate();
        }



        protected int ExecuteNonQuery(DbCommand cmd)
        {
            return cmd.ExecuteNonQuery();
        }

        protected IDataReader ExecuteReader(DbCommand cmd)
        {
            return ExecuteReader(cmd, CommandBehavior.Default);
        }

        protected IDataReader ExecuteReader(DbCommand cmd, CommandBehavior behavior)
        {
            return cmd.ExecuteReader(behavior);
        }

        protected object ExecuteScalar(DbCommand cmd)
        {
            return cmd.ExecuteScalar();
        }
    }
}
