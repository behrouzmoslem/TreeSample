﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;
using MPTT.BLL;

/// <summary>
/// Summary description for SqlTreeProvider
/// </summary>
namespace MPTT.DAL
{
    public class SqliteTreeProvider : TreeProvider
    {
        string ContentTableName;
        public SqliteTreeProvider()
            : base()
        {
            ContentTableName = "tblTree";
        }

        public SqliteTreeProvider(string conString, Boolean enableCaching, int chachDuration)
            : base (conString)
        {
            ContentTableName = "tblTree";
        }

        public override void TruncateTable()
        {

            if (!InternalBeginUpdate())
                return;

            //Output, provides you access to inserted and deleted logical tables. 
            SqlCommand cmd = new SqlCommand(string.Format("TRUNCATE TABLE {0}", ContentTableName), con);
            ExecuteNonQuery(cmd);

            InternalEndUpdate();
        }

        public override int AddNode(string title, int parentID, bool rebuiled)//returns ID of the added node
        {
            if (!InternalBeginUpdate())
                return -1;

            //Output, provides you access to inserted and deleted logical tables. 
            SqlCommand cmd = new SqlCommand(string.Format("INSERT INTO {0} (parentID,Title,lft,rgt,leafID,isLeaf) OUTPUT inserted.ID VALUES (@ParentID,@Title,@Left,@Right,@LeafID,@IsLeaf)", ContentTableName), con);
            //cmd.CommandType = CommandType.TableDirect;
            cmd.Parameters.AddWithValue("@Title", title);
            cmd.Parameters.AddWithValue("@ParentID", parentID);
            cmd.Parameters.AddWithValue("@Left", 0);
            cmd.Parameters.AddWithValue("@Right", 0);
            cmd.Parameters.AddWithValue("@LeafID", 0);
            cmd.Parameters.AddWithValue("@IsLeaf", 0);
            //Object obj = ExecuteScalar(cmd);
            int ID = (int)ExecuteScalar(cmd);

            //Rbuilding the tree by Walking or Traversing through
            if (rebuiled)
            {
                RebuildTree(1, 1);
                //IdentifyAllLeafIDs(100);
            }

            InternalEndUpdate();
            //return the ID  of the inserted record
            return ID;//
        }

        public override void DeleteNode(int id)
        {
            if (!InternalBeginUpdate())
                return;
            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE ID={1}", ContentTableName, id), con);
            List<MpttNode> nodes = GetNodeCollectionFromReader(ExecuteReader(cmd));
            if (nodes.Count > 0)
            {
                MpttNode node = nodes[0];
                cmd.CommandText = string.Format("DELETE FROM {0} WHERE ID={1}", ContentTableName, id);
                ExecuteNonQuery(cmd);

                cmd.CommandText = string.Format("UPDATE {0} SET lft=lft-2, rgt=rgt-2 WHERE lft>{1} AND rgt<{2}", ContentTableName, node.Left, node.Right);
                ExecuteNonQuery(cmd);
            }
            InternalEndUpdate();
        }

        public override List<MpttNode> GetLevelZeroNodes()
        {
            if (!InternalBeginUpdate())
                return null;
            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE parentID=0", ContentTableName), con);
            List<MpttNode> list = GetNodeCollectionFromReader(ExecuteReader(cmd));
            InternalEndUpdate();
            return list;
        }

        public override List<MpttNode> GetSubTree(int parentID, bool includeParent)
        {
            if (!InternalBeginUpdate())
                return null;
            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE ID={1}", ContentTableName, parentID), con);
            List<MpttNode> nodes = GetNodeCollectionFromReader(ExecuteReader(cmd));
            List<MpttNode> list = null;
            if (nodes.Count > 0)
            {
                MpttNode node = nodes[0];
                cmd.CommandText = string.Format("SELECT * FROM {0} WHERE lft>{1} and rgt<{2}", ContentTableName, node.Left, node.Right);
                list = GetNodeCollectionFromReader(ExecuteReader(cmd));
            }
            else
                list = null;
            InternalEndUpdate();
            return list;
        }

        public override List<MpttNode> GetSiblings(int nodeID)
        {
            if (!InternalBeginUpdate())
                return null;
            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE ID={1}", ContentTableName, nodeID), con);
            List<MpttNode> nodes = GetNodeCollectionFromReader(ExecuteReader(cmd));
            List<MpttNode> list = null;
            if (nodes.Count > 0)
            {
                MpttNode node = nodes[0];
                cmd.CommandText = string.Format("SELECT * FROM {0} WHERE parentID={1} and NOT ID={2}", ContentTableName, node.ParentID, node.ID);
                list = GetNodeCollectionFromReader(ExecuteReader(cmd));
            }
            else
                list = null;
            InternalEndUpdate();
            return list;
        }

        public override int GetParentID(int nodeID)
        {
            if (!InternalBeginUpdate())
                return -1;

            SqlCommand cmd = new SqlCommand(string.Format("SELECT parentID FROM {0} WHERE ID={1}", ContentTableName, nodeID), con);
            int ID = (int)ExecuteScalar(cmd);

            InternalEndUpdate();

            return ID;
        }

        public override MpttNode GetNode(int nodeID)
        {
            if (!InternalBeginUpdate())
                return null;

            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE ID={1}", ContentTableName, nodeID), con);
            List<MpttNode> nodes = GetNodeCollectionFromReader(ExecuteReader(cmd));
            MpttNode node = null;
            if (nodes.Count > 0)
                node = nodes[0];

            InternalEndUpdate();
            
            return node;
        }
        public override MpttNode GetNodeByLeafID(int leafID)
        {
            if (!InternalBeginUpdate())
                return null;

            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE LeafID={1}", ContentTableName, leafID), con);
            List<MpttNode> nodes = GetNodeCollectionFromReader(ExecuteReader(cmd));
            MpttNode node = null;
            if (nodes.Count > 0)
                node = nodes[0];

            InternalEndUpdate();

            return node;
        }

        public override List<MpttNode> GetChildren(int parentID)
        {
            if (!InternalBeginUpdate())
                return null;

            SqlCommand cmd = new SqlCommand(string.Format("SELECT * FROM {0} WHERE parentID={1}", ContentTableName, parentID), con);
            List<MpttNode> list = GetNodeCollectionFromReader(ExecuteReader(cmd));

            InternalEndUpdate();

            return list;
        }


        public override int DescendantsCount(int parentID)
        {
            if (!InternalBeginUpdate())
                return -1;

            SqlCommand cmd = new SqlCommand(String.Format("SELECT ((rgt-lft-1)/2) as descCount FROM {0} WHERE ID={1}", ContentTableName, parentID), con);
            int descCount = -1;
            try
            {
                descCount = (int)ExecuteScalar(cmd);
            }
            catch (SqlException exp)
            {
                Console.WriteLine(exp.ToString());
            }

            InternalEndUpdate();

            return descCount;
        }

        public override int RebuildTree(int parentID, int lft)
        {
            if (!InternalBeginUpdate())
                return -1;
            // the right value of this node is the left value + 1 
            int rgt = lft + 1;

            // get all children of this node 
            List<MpttNode> nodes = GetChildren(parentID);

            // recursive execution of this function for each child of this node 
            // rgt is the current right value, which is incremented by the RebuildTree function 
            foreach (MpttNode node in nodes)
            {
                rgt = RebuildTree(node.ID, rgt);
            }

            // we've got the left value, and now that we've processed 
            // the children of this node we also know the right value 
            //defines a scope, outside of which an object or objects will be disposed
            int isLeaf = (((rgt - lft - 1) / 2) == 0) ? 1 : 0;
            SqlCommand cmd = new SqlCommand(string.Format("UPDATE {0} SET lft={1}, rgt={2}, isLeaf={3} WHERE ID={4}", ContentTableName, lft, rgt, isLeaf, parentID), con);
            ExecuteNonQuery(cmd);

            InternalEndUpdate();

            // return the right value of this node + 1 
            return rgt + 1;
        }

        public override void IdentifyAllLeafIDs(int startLeafID)
        {
            if (!InternalBeginUpdate())
                return;

            SqlCommand cmd = new SqlCommand(string.Format("UPDATE {0} SET {0}.leafID = tblTemp.tempID + {1} - 1 FROM (SELECT ROW_NUMBER() OVER (ORDER BY ID) as tempID,* FROM {0} WHERE isLeaf=1) AS tblTemp WHERE {0}.ID = tblTemp.ID", ContentTableName, startLeafID), con);
            ExecuteNonQuery(cmd);

            InternalEndUpdate();
        }
        public override void IdentifyAllNodes(int startLeafID)
        {
            if (!InternalBeginUpdate())
                return;

            SqlCommand cmd = new SqlCommand(string.Format("UPDATE {0} SET {0}.leafID = tblTemp.tempID + {1} - 1 FROM (SELECT ROW_NUMBER() OVER (ORDER BY ID) as tempID,* FROM {0}) AS tblTemp WHERE {0}.ID = tblTemp.ID", ContentTableName, startLeafID), con);
            ExecuteNonQuery(cmd);

            InternalEndUpdate();
        }
        public override void IdentifySingleLeafID(int ID, int leafID)
        {
            if (!InternalBeginUpdate())
                return;

            SqlCommand cmd = new SqlCommand(string.Format("UPDATE {0} SET leafID = {1} WHERE ID = {2}", ContentTableName, leafID, ID), con);
            ExecuteNonQuery(cmd);

            InternalEndUpdate();
        }
    }
}