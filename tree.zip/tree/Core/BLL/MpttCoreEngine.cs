﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Data.SqlClient;
using MPTT.BLL;
using MPTT.DAL;
using System.IO;
using System.Drawing.Drawing2D;

namespace MPTT.BLL
{
    public class MpttCoreEngine
    {
        private TreeProvider mpttTree;

        public MpttCoreEngine()
            : this("MPTT.DAL.SqlTreeProvider")
        { 
        }

        public MpttCoreEngine(string provider)
        {
            //use any provider selected by the user of the class
            Type providerType = Type.GetType(provider);
            mpttTree = (TreeProvider)Activator.CreateInstance(providerType);
        }

        private char _levelDelimiter = ' ';
        public char LevelDelimiter
        {
            get { return _levelDelimiter; }
            set { _levelDelimiter = value; }
        }

        private char _leafIdDelimiter = '#';
        public char LeafIdDelimiter
        {
            get { return _leafIdDelimiter; }
            set { _leafIdDelimiter = value; }
        }

        public void SetConnectionString(string connectionString)
        {
            mpttTree.ConnectionString = connectionString;
        }

        public delegate void RetriveTreeNodeObject(TreeNode tree);
        public void IterateTreeNodes(TreeNode tree, RetriveTreeNodeObject callback)
        {
            //tree is the tree collection, that contains indevidual subtrees
            foreach (TreeNode parentNode in tree.Nodes)
            {
                callback(parentNode);
                TreeIteration(parentNode, callback);
            }
        }
        public void TreeIteration(TreeNode parentNode, RetriveTreeNodeObject callback)
        {
            foreach (TreeNode node in parentNode.Nodes)
            {
                callback(node);
                TreeIteration(node, callback);
            }
        }
        
        //---------------------------------------------------------------------------------------
        //Text -> Tree
        //---------------------------------------------------------------------------------------
        public TreeNode ConvertTextIntoTree(string text, char levelDelimiter, char leafIdDelimiter)
        {
            _levelDelimiter = levelDelimiter;
            _leafIdDelimiter = leafIdDelimiter;
            string[] lines = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return ConvertTextIntoTree(lines);
        }
        public TreeNode ConvertTextIntoTree(string fileName)
        {
            try
            {
                string[] lines = System.IO.File.ReadAllLines(fileName, Encoding.GetEncoding(1256));
                return ConvertTextIntoTree(lines);
            }
            catch { }
            return null;
        }

        public TreeNode ConvertTextIntoTree(string[] lines)
        {
            try
            {
                if (lines.Length > 0)
                {
                    //
                    //Assume a single tree starts from specific level like 0 level
                    //Assume a node is identical to a line in the text
                    //Assume the level is the number of spaces in front of the node title
                    //So, The text file may contains more than one tree
                    //then, I will collect all of that trees into one TreeNode-object called treeCollection
                    //
                    TreeNode treeCollection = new TreeNode("Trees collection");
                    //--------------------------------
                    // Use nextLine variable to control contiguase/linear-access to lines/nodes array
                    for (int nextLine = 1; nextLine <= lines.Length; nextLine++)
                    {
                        string line = lines[nextLine - 1];
                        //Calculate the node level, count spaces in front of the text line
                        //The level(parents level) will be the same for each single tree contained into the text file
                        int parentLevel;
                        int leafID;
                        line = AnalyzeTextLine(line, out parentLevel, out leafID);
                        TreeNode parentNode = new TreeNode(line.Trim());
                        parentNode.Tag = new MpttNode(nextLine, 0, 0, 0, leafID, 0, parentNode.Text);
                        treeCollection.Nodes.Add(parentNode);
                        nextLine = AddLevelToTree(lines, parentNode, nextLine, parentLevel);
                    }
                    return treeCollection;
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message.ToString());
            }
            return null;
        }
        public int AddLevelToTree(string[] lines, TreeNode parentNode, int childLine, int parentLevel)
        {
            //
            int expectedChildLevel = parentLevel + 1;
            TreeNode lastChildNode = new TreeNode();//Keep track of the last added node to parent 
            //
            for (int lineID = childLine; lineID < lines.Length; lineID++)
            {
                string line = lines[lineID];
                //the child level is the count of spaces in front of the text line
                int actualLevel;
                int leafID;
                line = AnalyzeTextLine(line, out actualLevel, out leafID);
                //------------------------
                if (actualLevel == expectedChildLevel)
                {
                    //add child to parent
                    lastChildNode = parentNode.Nodes.Add(line.Trim());
                    lastChildNode.Tag = new MpttNode(lineID+1, ((MpttNode)parentNode.Tag).ID, 0, 0, leafID, 0, lastChildNode.Text);
                }
                else
                {
                    if (actualLevel > expectedChildLevel)
                    {
                        //Use last child as a parent to the current line
                        lineID = AddLevelToTree(lines, lastChildNode, lineID, expectedChildLevel) - 1;
                        //proccess the returned line again, it's not added to the tree
                    }
                    else
                    {
                        return lineID;//return the last counted/proccessed line
                    }
                }
            }
            return lines.Length;//return the last counted/proccessed line
        }
        public string AnalyzeTextLine(string line, out int parentLevel, out int leafID)//returns first splited line
        {
            leafID = 0;
            parentLevel = 0;
            while (line[parentLevel] == _levelDelimiter) parentLevel++;
            string[] tl = line.Split(_leafIdDelimiter);
            if (tl.Length > 2)
                leafID = Int32.Parse(tl[2]);
            return tl.Length > 0 ? tl[0].Trim(_levelDelimiter) : "";
        }
        //---------------------------------------------------------------------------------------
        public TreeNode ConvertTextTableIntoTree(string text, Boolean tabular)
        {
            //<summary>Fields per line: ElementID \t ParentID \t ElementName \t HitLinkID, !! WITHOUT EMPTY FIELDS !! </summary>
            string[] lines = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return ConvertTextTableIntoTree(lines);
        }
        public TreeNode ConvertTextTableIntoTree(string fileName)
        {
            if (!System.IO.File.Exists(fileName))
                return null;
            string[] lines = System.IO.File.ReadAllLines(fileName, Encoding.GetEncoding(1256));        //<summary>Fields per line: ElementID \t ParentID \t ElementName \t HitLinkID, !! WITHOUT EMPTY FIELDS !! </summary>
            return ConvertTextTableIntoTree(lines);
        }
        public TreeNode ConvertTextTableIntoTree(string[] lines)
        {
            if (lines.Length <= 2)
                return null;
            //Neglect first two lines from proccessing, they are (Head titles and empty line)
            TreeNode treeCollection = new TreeNode();
            SortedList<string, TreeNode> nodes = new SortedList<string, TreeNode>();
            for (int id = 2; id < lines.Length; id++)
            {
                string line = lines[id];
                char[] separtors = { '\t', '#' };
                string[] fileds = line.Split(separtors, StringSplitOptions.RemoveEmptyEntries);
                fileds[0].Trim(); fileds[1].Trim(); fileds[2].Trim(); fileds[3].Trim(); fileds[4].Trim();
                //now convert the text line into TreeNode
                //the node may actually be created in a previouse iteration of this for-loop iterations
                //actully, it may be created as anonymous-parent
                //so, try to obtain it first before deciding to create it from scratch
                TreeNode curNode = null;
                try { curNode = nodes[fileds[0]]; }
                catch (Exception) { curNode = null; }
                if (curNode == null)
                {
                    curNode = new TreeNode(fileds[2]);
                    nodes.Add(fileds[0], curNode);
                }
                //fill in node fields, whether it is newlly created or actually retrieved from the sorted list
                curNode.Text = fileds[2];
                curNode.Tag = new MpttNode(int.Parse(fileds[0]), int.Parse(fileds[1]), int.Parse(fileds[3]), int.Parse(fileds[4]), 0, 0, curNode.Text);
                //
                //The parent may be created before in a previouse iteration
                //or, it may not be created yet
                //whatever the case, we must have a parent for the current node
                //that way we will end up with an anonymous parent node, that carry 0-Level-nodes
                TreeNode parentNode = null;
                try { parentNode = nodes[fileds[1]]; }
                catch (Exception) { parentNode = null; }
                if (parentNode == null)
                {
                    parentNode = new TreeNode(fileds[1]);//anonymous parent, parent that has no name
                    nodes.Add(fileds[1], parentNode);
                }
                //
                parentNode.Nodes.Add(curNode);
            }
            //How to know the least significant parents
            //we may walked through more than a tree, where each one has a single parent
            //The answer is, compare the Level of all nodes untill reaching Level==0 nodes
            //and, collect them into one collection
            IEnumerator<KeyValuePair<string, TreeNode>> nodesEnum = nodes.GetEnumerator();
            nodesEnum.Reset();
            while (nodesEnum.MoveNext())
            {
                TreeNode node = (TreeNode)nodesEnum.Current.Value;
                if (node.Level == 0)
                    treeCollection.Nodes.Add(node);
            }
            TreeNode lastNode = treeCollection.Nodes.Count > 1 ? treeCollection : treeCollection.Nodes[0];
            lastNode.Text = "Trees collection";
            return lastNode;
        }
        //---------------------------------------------------------------------------------------
        //Tree -> SQL
        //---------------------------------------------------------------------------------------
        public void ConvertTreeIntoMptt(TreeNode tree)
        {
            //Table fields must be: ID, parentID, Title, lft, rgt, LeafID 
            mpttTree.BegingUpdate();
            //Emptize tblTree 
            mpttTree.TruncateTable();
            //Put each tree into our Sql-Db-schema
            foreach (TreeNode subTree in tree.Nodes)
            {
                int ID = AddLevelToMptt(subTree, 0);
                //build each sub tree indevidualy
                mpttTree.RebuildTree(ID, 1);
            }
            mpttTree.EndUpdate();
        }
        public int AddLevelToMptt(TreeNode parentNode, int parentID)
        {
            int ID = mpttTree.AddNode(parentNode.Text, parentID, false);
            ((MpttNode)parentNode.Tag).ID = ID;
            mpttTree.IdentifySingleLeafID(ID, ((MpttNode)parentNode.Tag).LeafID);
            foreach (TreeNode node in parentNode.Nodes)
            {
                AddLevelToMptt(node, ID);
            }
            return ID;
        }
        //---------------------------------------------------------------------------------------

        //---------------------------------------------------------------------------------------
        //SQL -> Tree
        //---------------------------------------------------------------------------------------
        public TreeNode ConvertMpttIntoTree()
        {
            mpttTree.BegingUpdate();

            TreeNode treeCollection = new TreeNode("Trees collection");
            treeCollection.Tag = null;

            List<MpttNode> mpttParents = mpttTree.GetLevelZeroNodes();
            foreach (MpttNode node in mpttParents)
            {
                TreeNode parentNode = new TreeNode(node.Title);
                parentNode.Tag = node;
                treeCollection.Nodes.Add(parentNode);

                AddMpttChildIntoTree(parentNode, node.ID);
            }
            mpttTree.EndUpdate();
            return treeCollection;

        }
        public void AddMpttChildIntoTree(TreeNode parentNode, int parentID)
        {
            List<MpttNode> nodes = mpttTree.GetChildren(parentID);
            foreach (MpttNode mpttNode in nodes)
            {
                TreeNode node = new TreeNode(mpttNode.Title);
                node.Tag = mpttNode;
                parentNode.Nodes.Add(node);
                AddMpttChildIntoTree(node, mpttNode.ID);
            }
        }
        //---------------------------------------------------------------------------------------

        //---------------------------------------------------------------------------------------
        //Tree -> Text
        //---------------------------------------------------------------------------------------
        public string ConvertTreeIntoText(TreeNode tree,Boolean includeLeafID)
        {
            List<string> lines = ConvertTreeIntoText(tree, 0, includeLeafID);
            string buf = "";
            foreach (string s in lines) buf += s + "\r\n";
            return buf;
        }
        public void ConvertTreeIntoText(TreeNode tree, string fileNamePath, int treeStartLevel)
        {
            List<string> lines = ConvertTreeIntoText(tree, treeStartLevel, true);
            System.IO.File.WriteAllLines(fileNamePath, lines.ToArray(), System.Text.Encoding.GetEncoding(1256));
        }
        public List<string> ConvertTreeIntoText(TreeNode tree, int treeStartLevel, Boolean includeLeafID)
        {
            //tree is the tree collection, that contains indevidual subtrees
            List<string> lines = new List<string>();
            foreach (TreeNode parentNode in tree.Nodes)
            {
                lines.Add(parentNode.Text.PadLeft(treeStartLevel + parentNode.Text.Length, _levelDelimiter) + (includeLeafID ? (_leafIdDelimiter + ((MpttNode)parentNode.Tag).LeafID.ToString()):""));
                AddLinesOfChildren(lines, parentNode, treeStartLevel + 1, includeLeafID);
            }
            return lines;
        }
        public void AddLinesOfChildren(List<string> lines, TreeNode parentNode, int childrenLevel, Boolean includeLeafID)
        {
            foreach (TreeNode node in parentNode.Nodes)
            {
                lines.Add(node.Text.PadLeft(childrenLevel + node.Text.Length, _levelDelimiter) + (includeLeafID ? (_leafIdDelimiter + ((MpttNode)node.Tag).LeafID.ToString()) : ""));
                AddLinesOfChildren(lines, node, childrenLevel + 1, includeLeafID);
            }
        }
        //---------------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------------
        //Tree -> Table
        //---------------------------------------------------------------------------------------
        public string ConvertTreeIntoTable(TreeNode tree, Boolean includeLeafID)
        {
            List<string> lines = ConvertTreeIntoTable(tree, 0, includeLeafID);
            string buf = "";
            foreach (string s in lines) buf += s + "\r\n";
            return buf;
        }
        public void ConvertTreeIntoTable(TreeNode tree, string fileNamePath, int treeStartLevel)
        {
            List<string> lines = ConvertTreeIntoTable(tree, treeStartLevel, true);
            System.IO.File.WriteAllLines(fileNamePath, lines.ToArray(), System.Text.Encoding.GetEncoding(1256));
        }
        public List<string> ConvertTreeIntoTable(TreeNode tree, int treeStartLevel, Boolean includeLeafID)
        {
            //tree is the tree collection, that contains indevidual subtrees
            List<string> lines = new List<string>();
            lines.Add("ID\tPrntID\tTitle\tLeft\tRight");
            lines.Add("_______\t_______\t_______\t_______\t_______");
            foreach (TreeNode parentNode in tree.Nodes)
            {
                MpttNode node = (MpttNode)parentNode.Tag;
                lines.Add(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", node.ID, node.ParentID, node.Title, node.Left, node.Right));
                AddTableLinesOfChildren(lines, parentNode, treeStartLevel + 1, includeLeafID);
            }
            return lines;
        }
        public void AddTableLinesOfChildren(List<string> lines, TreeNode parentNode, int childrenLevel, Boolean includeLeafID)
        {
            foreach (TreeNode tNode in parentNode.Nodes)
            {
                MpttNode node = (MpttNode)tNode.Tag;
                lines.Add(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", node.ID,node.ParentID,node.Title,node.Left,node.Right));
                AddTableLinesOfChildren(lines, tNode, childrenLevel + 1, includeLeafID);
            }
        }
        //---------------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------------
        //Nodes Re-Identification for leafs/all
        //---------------------------------------------------------------------------------------
        public void IdentifyLeafs(int leafStartID)
        {
            //Number each leave starting from the given value
            //No matter if leafs belongs to deferent sub-trees
            mpttTree.IdentifyAllLeafIDs(leafStartID);
        }
        public void IdentifyAllNodes(int startID)
        {
            //Number each leave starting from the given value
            //No matter if leafs belongs to deferent sub-trees
            mpttTree.IdentifyAllNodes(startID);
        }
        //---------------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------------
        //Generating a dummy tree
        //---------------------------------------------------------------------------------------
        public string FormatDumyTree(Boolean textual, int maxLen, char charDelimiter, string title)
        {
            int ser = 0;
            string text = "";
            //--------------
            if (textual)
            {
                text = "";
                string pading = "";
                for (int i = 0; i < maxLen; i++)
                {
                    ser = series(maxLen, i, ser);
                    text += string.Format("{0}{2}{1}\r\n", pading.PadLeft(((i + ser) < 0 ? 0 : (i + ser)), charDelimiter), i + 1, title);
                }

            }
            else
            {
                text = "ID\tPrntID\tTitle\tLeft\tRight";
                text += "\r\n_______\t_______\t_______\t_______\t_______";
                for (int i = 0; i < maxLen; i++)
                {
                    ser = series(maxLen, i, ser);
                    text += string.Format("\r\n{0}\t{1}\t{2}{0}\t0\t0", i + 1, (i + ser) < 0 ? i : (i + ser), title);
                }
            }
            return text;
        }
        private int series(int max, int i, int last)
        {
            int avr = max / 2;
            int mod = i % avr;
            int range = (mod - i) / avr; //[0-5]=0, [6-9]=-1 ,[10-15]=-2 ...
            last += (range + (last % 2));//after avr becomes, -1, -3, -5, -7, ...
            return last;
        }
        //---------------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------------
        //Generate an image for the tree
        //---------------------------------------------------------------------------------------
        public Bitmap DrawTree(TreeNode node)
        {
            int marginX = Branch.marginX, spanY = Branch.spanY,
                w = Branch.marginX, h = Branch.spanY;
            Font fnt = Branch.font;

            //---------------------------------------------------------------------------------------
            //Measure the distribution of tree nodes in the space, using anonymous funcition
            //---------------------------------------------------------------------------------------
            Bitmap bmp = new Bitmap(w, h);
            Graphics memGraph = Graphics.FromImage(bmp);
            //use lambada initialization for anonymous functions
            RetriveTreeNodeObject measure = (tnode) =>
            {
                Boolean first = true;//flags the recently provided tnode during looping its parents 
                //create new drawing-branch with apropriate size
                Branch cb = new Branch(tnode);
                ((MpttNode)tnode.Tag).Tag = cb;
                cb.Text = ((MpttNode)tnode.Tag).Left.ToString() + " | " + tnode.Text + " | " + ((MpttNode)tnode.Tag).Right.ToString();
                cb.sz = Size.Ceiling(memGraph.MeasureString(cb.Text, fnt));
                cb.delta = marginX;//additional width caused by margins and children nodes
                cb.Location = new Point(marginX/2, ((tnode.Level - 1) * spanY));
                //loop through parents of the provided tnode
                while (tnode.Parent != null && tnode.Parent.Tag != null)
                {
                    Branch b = (Branch)((MpttNode)tnode.Tag).Tag;
                    TreeNode p = tnode.Parent;
                    Branch pb = (Branch)((MpttNode)p.Tag).Tag;
                    //Increase parent width by the currently provided width
                    int pbw = pb.sz.Width + pb.delta;
                    int bw = b.sz.Width + b.delta;
                    pb.kidsW -= !first ? b.prevW : 0;
                    pb.delta += ((bw + pb.kidsW - pbw) + Math.Abs(bw + pb.kidsW - pbw)) / 2;
                    pbw = pb.sz.Width + pb.delta;
                    pb.kidsW += bw;
                    b.prevW = bw;
                    //Adjust only current node locatoin according to its parent
                    if (first)
                    {
                        //Child comes after parent, so, location is correctly adjusted
                        b.Location = new Point(pb.Location.X + pb.kidsW - bw, ((tnode.Level - 1) * spanY));
                        first = false;
                    }
                    //keep track of the maximum width and height
                    w = Math.Max(pb.Location.X + pbw + Branch.marginX/2, w);
                    h = Math.Max((((tnode.Level - 1) * spanY)) + spanY, h);
                    //Get the next parent
                    tnode = p;
                }
                if (first && w>marginX)
                {
                    //support more than one tree by catching cases of second or heigher levelZero-node
                    //supporting means to draw multiple trees beside each others
                    cb.Location.Offset(w,0);
                    w = Math.Max(cb.Location.X+cb.sz.Width+cb.delta, w);
                }
            };
            IterateTreeNodes(node, measure);//iterate the provided tree nodes to measure nodes coordinates
            //---------------------------------------------------------------------------------------
            //Draw and distribute tree nodes in the space of an image, using also anonymous funcition
            //---------------------------------------------------------------------------------------
            memGraph.Dispose();
            bmp.Dispose();
            bmp = new Bitmap(w, h);
            memGraph = Graphics.FromImage(bmp);
            Rectangle gradientrect = new Rectangle(new Point(0, 0), new Size(w, h));
            LinearGradientBrush brush = new LinearGradientBrush(gradientrect, Color.White, Color.Cornsilk, LinearGradientMode.Vertical);
            memGraph.FillRectangle(brush,gradientrect);
            //use lambada initialization for anonymous functions
            RetriveTreeNodeObject draw = (tnode) =>
            {
                MpttNode mpttNode = (MpttNode)tnode.Tag;
                int level = tnode.Level;
                Branch b = (Branch)((MpttNode)tnode.Tag).Tag;
                Rectangle rect = b.rail;
                if (tnode.Parent.Tag != null)
                {
                    memGraph.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    memGraph.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Default;
                    Pen pen = new Pen(new SolidBrush(Color.Red), 1.0F);
                    pen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                    memGraph.DrawLine(pen, ((Branch)((MpttNode)tnode.Parent.Tag).Tag).bottomJoin, b.topJoin);
                }
                brush = new LinearGradientBrush(rect, Color.White, Color.BurlyWood, LinearGradientMode.Vertical);
                memGraph.FillRectangle(brush, rect);
                memGraph.DrawRectangle(new Pen(new SolidBrush(Color.Brown)), rect);
                StringFormat format = new StringFormat();
                format.FormatFlags = StringFormatFlags.NoClip;
                memGraph.DrawString(
                    b.Text,
                    fnt,
                    new SolidBrush(Color.Black),
                    new RectangleF(rect.Left,rect.Top,rect.Width,rect.Height),
                    format);
                //memGraph.DrawRectangle(new Pen(new SolidBrush(Color.Green)), b.wide);
            };
            IterateTreeNodes(node, draw);//iterate the provided tree nodes
            memGraph.Dispose();
            //---------------------------------------------------------------------------------------
            //Return the bitmap for displaying, saving, editing .. etc
            //---------------------------------------------------------------------------------------
            return bmp;
        }
        public class Branch
        {
            //The branch is a rectangulare area for a parent node and some children
            //the branch normally contained within another, so a child may be itself a branch
            //if the internal branch inflated then the outer must follow that inflation with similar one
            //that way I measured the locations of tree nodes vertically on X-axis.
            //The horizental measurments on Y-axis are easier, just using depth level of the 
            //node in the tree with an apropriate/optional line height like spanY to calculate a suitable row for the node.
            public Branch(Object tag)
            {
                Tag = tag;
            }
            public Rectangle rc;//branch width and location, height is not important
            public Size sz;//text size
            public string Text;
            public Object Tag;//refrence to an assocciated object
            public static Font font = new Font("Times New Roman", 8.0F);
            public static int spanY = 100;
            public static int marginX = 10;
            public static int marginY = 30;
            public int delta = 0, kidsW = 0, prevW = 0;
            public Point Location = new Point(0,0);

            public Rectangle wide
            {
                get
                {
                    return new Rectangle(Location.X, Location.Y, sz.Width + delta, 5);
                }
            }
            public Rectangle rail
            {
                get
                {
                    //Rectangle rct = rc;
                    //if (rct.Width < sz.Width)
                    //{
                    //    int def = ((sz.Width - rct.Width) / 2) * 2;
                    //    rct.Inflate(def / 2, 0);
                    //    rct.Offset(def / 2, 0);
                    //}
                    //return new Rectangle(rct.Left + (rct.Width - sz.Width) / 2 - 1, rct.Top, sz.Width + 1, sz.Height);
                    int w = sz.Width + delta;
                    return new Rectangle(Location.X + (w - sz.Width) / 2 - 1, Location.Y + marginY, sz.Width + 1, sz.Height);
                }
            }
            public Point topJoin
            {
                get
                {
                    Rectangle rect = rail;
                    return new Point(rect.Left + (rect.Width / 2), rect.Top);
                }
            }
            public Point bottomJoin
            {
                get
                {
                    Rectangle rect = rail;
                    return new Point(rect.Left + (rect.Width / 2), rect.Bottom);
                }
            }
        }
    }
}
