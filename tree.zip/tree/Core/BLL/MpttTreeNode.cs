﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;

/// <summary>
/// Each node Corresponds to a record in tblTree
/// </summary>
namespace MPTT.BLL
{
    public class MpttNode
    {
        /* 
        MPTT: stands for Modified Preorder Tree Traversal 
        */
        public MpttNode(int id, int pId, int lft,int rgt,int leafID,int isLeaf,string title)
        {
            _id = id;
            _parentID = pId;
            _lft = lft;
            _rgt = rgt;
            _leafID = leafID;
            _title = title;
            _isLeaf = isLeaf;
        }

        protected string _title;
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private int _lft;
        public int Left
        {
            get { return _lft; }
            set { _lft = value; }
        }

        private int _rgt;
        public int Right
        {
            get { return _rgt; }
            set { _rgt = value; }
        }

        private int _isLeaf;
        public int IsLeaf
        {
            get { return _isLeaf; }
            set { _isLeaf = value; }
        }

        protected int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value;  }
        }

        protected int _leafID;
        public int LeafID
        {
            get { return _leafID; }
            set { _leafID = value;  }
        }

        protected int _parentID;
        public int ParentID
        {
            get { return _parentID; }
            set { _parentID = value;  }
        }

        public Object Tag;
    }

}